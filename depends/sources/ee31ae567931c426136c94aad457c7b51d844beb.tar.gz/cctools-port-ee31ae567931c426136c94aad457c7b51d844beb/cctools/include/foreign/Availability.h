//fake headers
#ifdef __APPLE__
#include_next <Availability.h>
#endif /* __APPLE__ */
