#ifdef __APPLE__
#include_next <AvailabilityMacros.h>
#endif /* __APPLE__ */
