/* AUTOMATICALLY GENERATED -- DO NOT EDIT */

#define HAVE_SYNC_BOOL_COMPARE_AND_SWAP_INT 1
#define HAVE_SYNC_BOOL_COMPARE_AND_SWAP_LONG 1
#define PROGRAM "libBlocksRuntime"
#define VERSION "0.1"
#define TARGET "linux"
#define CFLAGS "-DBlocksRuntime_EXPORTS -fPIC -std=c99 -Wall -Wextra -W -pedantic -Wno-unused-parameter"
